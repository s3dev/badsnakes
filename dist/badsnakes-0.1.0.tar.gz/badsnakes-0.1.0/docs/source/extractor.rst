====================
Module: extractor.py
====================

.. automodule:: badsnakes.libs.extractor
    :members:
    :member-order: bysource
    :inherited-members:
    :private-members:
    :show-inheritance:
    :exclude-members: __dict__, __module__, __weakref__

