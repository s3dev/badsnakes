====================
Module: badsnakes.py
====================

This module provides the primary interface and processing controller for
the ``badsnakes`` command line utility.

.. automodule:: badsnakes.badsnakes
    :members:
    :member-order: bysource
    :inherited-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :exclude-members: __dict__, __module__, __weakref__
 
