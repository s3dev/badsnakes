================
Module: enums.py
================

.. automodule:: badsnakes.libs.enums
    :members:
    :member-order: bysource
    :private-members:
    :show-inheritance:
    :exclude-members: __dict__, __module__, __weakref__

