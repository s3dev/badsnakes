
# A toolset to identify malware in Python projects.

Currently a **placeholder** for when this project is ready in the near future.

The ``badsnakes`` project is a CPython library and command line utility which plugs the gap in malware analysis for Python-based malware by employing code and syntax analysis, searching for various patterns and techniques used by threat actors.


## Installation
Coming soon ...


## Toolset
Coming soon ...


## Using the Library
Coming soon ...


## Additional Information
Coming soon ...

