=================
Module: module.py
=================

.. automodule:: badsnakes.libs.module
    :members:
    :member-order: bysource
    :inherited-members:
    :private-members:
    :show-inheritance:
    :exclude-members: __dict__, __module__, __weakref__

