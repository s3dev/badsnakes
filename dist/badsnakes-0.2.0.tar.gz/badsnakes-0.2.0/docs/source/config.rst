=================
Module: config.py
=================

.. automodule:: badsnakes.libs.config
    :members:
    :member-order: bysource
    :inherited-members:
    :private-members:
    :show-inheritance:
    :exclude-members: __dict__, __module__, __weakref__

